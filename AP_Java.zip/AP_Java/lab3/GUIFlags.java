// Lab 3: GUI Flags
// Justin Varga

import javax.swing.*; // For JFrame and JPanel
import java.awt.*; // For Color and Container

public class GUIFlags
{
	public static void main(String[] args)
	{
		// France
		Color[] frenchColors = {new Color(0, 85, 164), Color.white, new Color(239, 65, 53)};
		flag("France", true, frenchColors);
		
		// The Netherlands
		Color[] dutchColors = {new Color(174, 28, 40), Color.white, new Color(33, 70, 139)};
		flag("the Netherlands", false, dutchColors);
		
		// Mauritius
		Color[] mauritianColors = {new Color(208, 28, 31), new Color(45, 51, 89), new Color(247, 183, 24), new Color(0, 134, 88)};
		flag("Mauritius", false, mauritianColors);
		
		// Bulgaria
		Color[] bulgarianColors = {Color.white, new Color(0, 155, 117), new Color(208, 28, 31)};
		flag("Bulgaria", false, bulgarianColors);
	}
	
	public static void flag(String country, boolean horizontal, Color[] colors)
	{
		JFrame frame = new JFrame();
		
		frame.setTitle("Flag of " + country);
		frame.setSize(600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		Container pane = frame.getContentPane();
	
		if (horizontal)
		{
			pane.setLayout(new GridLayout(1, colors.length));	
		}
		else
		{
			pane.setLayout(new GridLayout(colors.length, 1));
		}
	
		for(Color c : colors)
		{
			JPanel panel = new JPanel();
			panel.setBackground(c);
			pane.add(panel);
		}
		
		frame.setVisible(true);
	}
	
}
