// Lab 11: Rectangle
// Justin Varga

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Rectangle extends JPanel
{
	private int width, height; 
	private Color color;
	private Point pt; // Coordinate of upper left corner of rectangle
	
	public Rectangle(int x, int y, int width, int height, Color color)
	{
		setLoc
		
		this.width = width;
		this.height = height;
		
		this.color = color;
		
		addComponentListener(new ComponentListener
		{
			public void componentMoved(Component ce)
			{
				moveAction(ce);
			}
		});
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Color bgColor = g.getColor();
		
		g.setColor(color);
		g.drawRectangle(x, y, l, h);
		g.setColor(bgColor);
	}
	
	public void moveAction(ComponentEvent ce)
	{
		Point p = ce.getComponent().getLocation();
		x = p.x;
		y = p.y;
	}
	
}
