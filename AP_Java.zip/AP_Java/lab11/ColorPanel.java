// Lab 11 : Color Panel
// Justin Varga

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ColorPanel extends JPanel
{
	private Rectangle rect1, rect2, selectedRect;
	private int mouseX, mouseY;
	
	public ColorPanel(Color color)
	{
		setBackground(color);
		
		rect1 = new Rectangle(50, 30, 75, 100, Color.RED);
		rect2 = new Rectangle(10, 10, 60, 200, Color.BLUE);
		
		selectedRect = null;
		
		addMouseListener(new PanelListener());
		addMouseMotionListener(new PanelMotionListener());
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		rect1.fill(g);
		rect1.draw(g);
	}
	
	private class PanelListener extends MouseAdapter
	{	
		public void mousePressed(MouseEvent eve)
		{// Selects the rectangle if it contains the point
			mouseX = eve.getX();
			mouseY = eve.getY();
			
			if (rect.containsPoint(mouseX, mouseY))
			{
				selectedRect = rect;
			}
		}
		
		public void mouseReleased(MouseEvent eve)
		{// Deselects the rectangle
			selectRect = null; 
		}
	}
	
	private class PanelMotionListener extends MouseMotionAdapter
	{
		public void mouseDragged(MouseEvent eve)
		{
			if (selectedRect != null)
			{// Computes the distance and moves the rectangle
				int x = eve.getX();
				int y = eve.getY();
				
				int dx = x - mouseX;
				int dy = y - mouseY;
				
				selectedRect.setLocation(dx, dy);
				selectedRect.updateLocation();
				
				mouseX = x;
				mouseY = y;
				
				repaint();
			}
		}
	} 
}
