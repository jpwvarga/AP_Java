// Lab 12: Rammanujin's Taxi
// Justin Varga

import java.util.*;
import java.io.*;
import java.lang.Math;

public class Taxi
{
    public static void main(String[] args) throws IOException
	{
		PrintWriter writer = new PrintWriter(new File("taxiInfo.txt"));
		int lowestSum = 0;
		
		for (int a = 1 ; a <= 100 ; a++)
		{
			for (int b = 1 ; b <= 100 ; b++)
			{
				for (int c = 1 ; c <= 100 ; c++)
				{
					for (int d = 1 ; d <= 100 ; d++)
					{
						int a3 = (int)Math.pow(a,3);
						int b3 = (int)Math.pow(b,3);
						int c3 = (int)Math.pow(c,3);
						int d3 = (int)Math.pow(d,3);
						
						if(d3 == a3+b3+c3 && 
						   a != b && a != c && a != d && 
						   b != c && b != d && 
						   c != d)
						{
							writer.println((a3 + b3) + "; " + "a = " + a + "; b = " + b + "; c = " + c + "; d = " + d);
							if (a3 + b3 < lowestSum || lowestSum == 0)
								lowestSum = a3 + b3;
						}
					}
				}	
			}
		}
		
		String lowString = "\nThe lowest \"taxi\" number is: " + lowestSum;
		
		writer.println(lowString);
		
		System.out.println("Beep beep! The taxi has finished!" + lowString);
	}
}
