import java.util.Scanner;

public class StringTest
{
	public static void main(String[] args)
	{
		Scanner reader = new Scanner(System.in);
		System.out.print("Enter sentence: ");
    String input = reader.nextLine();  //reader returns a regular string
    SuperString s = new SuperString(input);  //make a new SuperString from regular string
    System.out.print("Enter word to count: ");
    String word = reader.nextLine();
		System.out.print("Enter integer for functions that require int input: ");
    int n = reader.nextInt();
		System.out.println("****TESTING!****\n");
		
		System.out.println("The word " + word + " appears " + s.count(word) + " times in " + s);
		
		System.out.println("The string " + s + " backwards is " + s.reverse());
	
		System.out.println("The string " + s + " despaced is " + s.despace());	
		
		System.out.println("The string " + s + " respaced is " + s.respace(n));

		System.out.println("The string " + s + "line-by-line:");
		s.lineByLine();
	
		System.out.println("The string " + s + " with every " + n + " letter is " + s.multipleString(n));

	}
}
