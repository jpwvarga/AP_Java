//extends means we have all of the regular string constructors and methods
//you will then add to them.  The provided StringTester program can be used
//test SuperString class (just make sure both .java files are in same lab folder).

public class SuperString
{
	//Instance variables, do not remove/modify
	private final String thisString;
	
	//Constructor, do not remove/modify
	//Note: String is not an extendable class so we have to cheat a bit
	public SuperString(String s)
	{
		thisString = s;  
		//in all methods below use thisString to "access yourself"
		//for example, thisString.indexOf("foo");
	}
	
	//Returns the number of occurrances of a substring / word in thisString
	//For example, if thisString is "How much wood could a woodchuck chuck if
	//a woodchuck could chuck wood" and word = "wood" then count should return 2
	//If no occourances are found, then -1 should be returned
	public int count(String word)
	{
		// Instantiate strings
		String str = new String(thisString);
		String checkWord = word;
		
		// Allow skipping if the word isn't present at all
		if(str.indexOf(word) == -1) 
		{
			//System.out.println("\tSkipping");
			return -1;
		}
		
		// Count up instances if you continue
		int count = 0;
		String thisWord = "";
		
		for (int i = 0 ; i < str.length() ; i++)
		{
			// Get the character at the given index
			char c = str.charAt(i);
			
			// Test at the delimiters
			if(c == ' ' || c == ',' || c == '.' || c == '?' || c == '!')	
			{
				//System.out.println("\tFound \"" + thisWord + "\" @ " + i);
				
				// Check if the word found is equivalent to the parameter
				if (thisWord.equals(word))
				{
					//System.out.println("\tIt is equivalent");
					count++;
				}
				
				//System.out.println("\tIt is NOT equivalent");
				thisWord = "";
			}
			else
			{
				thisWord += str.charAt(i);
			}
		}
		
		// If there is no instance of the word, return -1
		if (count == 0)
		{
			//System.out.println("\tCount was 0");
			return -1;
		}
		else 
		{
			//System.out.println("\tCount wasn't 0");
			return count;
		}
		
		/*
		int index = 0;
		
		
		for (int n = 0 ; index >= 0 && index < thisString.length() ; n++)
		{	
			// Check if word is part of another word
			if (index > 0 && ) // Checks if at start of word
			{
				if (str.charAt(index - 1) == ' ')
				{
					checkWord = checkWord + " ";
				}
			}
				
			if (index < str.length() - word.length() && str.charAt(index + word.length()) == ' ') // Checks if at end of word
			{
				checkWord = " " + checkWord;
			}
			
			// Check if word is present
			index = str.indexOf(checkWord);
				
			if (index == -1) 
			{ // When the word is not present
				if (n == 0)
				{ // When the word is never present
					return -1;
				}
				break;
			}
			else
			{// When the word is present
				// Shorten string to avoid recounting / infinite loop
				str = str.substring(index + checkWord.length());
				count++;
			}
		}
		*/
	}
	
	
	//Returns a String that is the current string written backwards
	public String reverse()
	{
		String reversedString = "";
		
		for (int i = thisString.length() - 1 ; i  >= 0 ; i--)
		{
			reversedString += thisString.charAt(i);
		}
		
		return reversedString;
	}
	
	
	//Returns a String that is the current string without any spaces
	public String despace()
	{
		String despacedString = "";
		
		for (int i = 0 ; i < thisString.length() ; i++)
		{
			if (thisString.charAt(i) != ' ')
			{
				despacedString += thisString.charAt(i);
			}
		}
		
		return despacedString;
	}
	
	
	//Returns a String that is the current string but despaced and then spaces added
	//every n characters.  For example: "The quick fox jumpped over the brown dog." becomes
	//"Theq uick foxj umpp edov erth ebro wndo g."
	public String respace(int n)
	{
		String respacedString = despace();
		
		if (n == 0) System.out.println("Error!");
		
		for (int i = n - 1 ; i < respacedString.length() ; i += n)
		{
			respacedString = respacedString.substring(0, i) + " " + respacedString.substring(i);
 		}
 		
		return respacedString;
	}
	
	
	//Output each word to System.out on its own line
	public void lineByLine()
	{
		String editString = "";
		
		for (int i = 0 ; i < thisString.length() ; i++)
		{
			if (thisString.charAt(i) == ' ')
			{
				editString += '\n';
			}
			else
			{
				editString += thisString.charAt(i);
			}
		}
		
		System.out.println(editString);
	}
	
	
	//Returns a String that is made from every nth letter of this string
	public String multipleString(int n)
	{
		String multipleStr = "";
		
		for (int i = n - 1 ; i < thisString.length() ; i += n)
		{
			multipleStr += thisString.charAt(i);
		}
		
		return multipleStr;
	}
	
	public String toString()
	{
		return new String(thisString);
	}

}
