// Minutes
// Justin Varga

// Converts number of years into minutes

import java.util.Scanner;

public class Minutes
{
	public static void main(String[] args)
	{
		Scanner reader = new Scanner(System.in);
	
		// Input
		int numberOfYears; 
		
		// Output
		int minutesInNYears;		
		
		// Other Variables
		int daysPerYear = 365;
		int hoursPerDay = 24;
		int minutesPerHour = 60;
		
		System.out.print("Enter number of years: ");
		numberOfYears = reader.nextInt();
		
		minutesInNYears = numberOfYears * daysPerYear * minutesPerHour;
		
		System.out.print(numberOfYears);
		System.out.print(" year(s) is ");
		System.out.print(minutesInNYears);
		System.out.println(" minutes.");
	}
}
