// Lab 4: PayCalculator
// Justin Varga

import java.util.Scanner;

public class PayCalculator
{
	public static void main(String[] args)
	{
		// Take Input
		Scanner reader = new Scanner(System.in);
		double hourlyWage, hoursWorked, overtimeHours;
		
		System.out.print("Hourly Wage: ");
		hourlyWage = reader.nextDouble();
		
		System.out.println("Hours Worked a Week: ");
		hoursWorked = reader.nextDouble();
		
		System.out.println("Total Overtime Hours a Work: ");
		overtimeHours = reader.nextDouble();
		
		// Calculate Pay: $$$ = Hourly Wage * Hours Worked + 1.5 * Wage * Overtime Hours
		double pay = hourlyWage * hoursWorked + 1.5 * hourlyWage * overtimeHours;
		
		double roundedPay = (double)((int)(pay * 100.0 + 0.5)) / 100.0;
		
		System.out.println("Weekly Pay is $" + pay + " or $" + roundedPay);
	}
}
