// Lab 4 : Circle
// Justin Varga

import java.lang.Math;
import java.util.Scanner;

public class Circle
{
	public static void main(String[] args)
	{
		Scanner reader = new Scanner(System.in);
		System.out.print("Input the radius: ");
		double radius = reader.nextDouble();
		
		double diameter = radius * 2;
		
		// Circumference
		double circumference = Math.PI * diameter; 
		System.out.println("\nThe CIRCUMFERENCE of a circle with radius " + radius + " is " + circumference + " units");
		
		// Diameter
		// [Declared above]
		System.out.println("The DIAMETER of a circle with radius " + radius + " is " + diameter + " units");
		
		// Area
		double area = Math.PI * radius * radius;
		System.out.println("The AREA of a circle with radius " + radius + " is " + area + " square units");
		
		// Volume of Cube
		double side = 2 * radius / Math.sqrt(3.0);
		double volume = side * side * side;
		System.out.println("\nThe VOLUME of a cube with radius " + radius + " is " + volume + " cubed units");
		
		// Surface Area of Cube
		double surfaceArea = 6.0 * side * side;
		System.out.println("The SURFACE AREA of a cube with radius " + radius + " is " + surfaceArea + " square units.");
	}
}
