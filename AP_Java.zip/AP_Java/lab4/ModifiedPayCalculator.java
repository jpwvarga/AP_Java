// Lab 4: Modified Pay Calculator
// Justin Varga

import java.util.Scanner;

public class ModifiedPayCalculator
{
	public static void main(String[] args)
	{
		Scanner reader = new Scanner(System.in);
		
		double hourlyWage, totalHoursWorked = 0, totalOvertimeHours = 0;
		double totalPay = 0.00, totalUnroundedPay = 0.00;
		
		String[] days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
		
		System.out.print("Hourly Wage: $");
		hourlyWage = reader.nextDouble();
		
		for (String day : days)
		{
			// Take Input
			double hoursWorked, overtimeHours;
			
			System.out.print("\nHours Worked on " + day + ": ");
			hoursWorked = reader.nextDouble();
			
			System.out.print("Total Overtime Hours on " + day + ": ");
			overtimeHours = reader.nextDouble();
		
			// Calculate Pay: $$$ = Hourly Wage * Hours Worked + 1.5 * Wage * Overtime Hours
			double dailyPay = hourlyWage * hoursWorked + 1.5 * hourlyWage * overtimeHours;
			double roundedDailyPay = (double)((int)(dailyPay * 100.0 + 0.5)) / 100.0;
		
			System.out.println(day + "'s Pay: $" + roundedDailyPay + "\t(Unrounded: $" + dailyPay + ")");
			
			// Total Calculations
			totalHoursWorked = totalHoursWorked + hoursWorked + overtimeHours;
			totalOvertimeHours = totalOvertimeHours + overtimeHours;
			
			totalPay = totalPay + roundedDailyPay;
			totalUnroundedPay = totalUnroundedPay + dailyPay;
		}
		
		System.out.println("\nWeekly Pay: $" + totalPay + "\t(Unrounded: $" + totalUnroundedPay + ")");
		
	}
}
