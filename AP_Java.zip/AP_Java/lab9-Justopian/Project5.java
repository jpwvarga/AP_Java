// Lab 9: 5-5 -- Filters
// Justin Varga

import images.*;
import java.util.*;

public class Project5
{
	public static void main(String[] args) throws Error
	{
		// Declare Variables
		Scanner reader = new Scanner(System.in);
		
		// Filename / Initialization
		APImage image;
		String filename;
		
		while (true)
		{	
			System.out.print("Enter Image Filename: ");
			filename = reader.next();
			
			try // Does an image with that name exist?
			{
				if (!filename.endsWith(".jpg"))
				{
					filename += ".jpg";
				}
					
				System.out.println("Attempting to find a file named \"" + filename + "\"...");
				image = new APImage(filename);
			}
			catch (Error|Exception err)
			{
				System.out.println("That file can not be found!");
				continue;
			}
			
			System.out.println("Image \"" + filename + "\" found successfully!\n");
			break;
		}	
		
		// Take Filter Input
		int filterRed, filterGreen, filterBlue;
		
		// Red
		while (true)
		{
			System.out.print("Enter Filter's Red Value: ");
			filterRed = reader.nextInt();
			
			if (Math.abs(filterRed) <= 255)
			{
				break;
			}
			
			System.out.println("\nPlease input a value between -255 and 255.");
		}
		
		// Green
		while (true)
		{
			System.out.print("Enter Filter's Green Value: ");
			filterGreen = reader.nextInt();
			
			if (Math.abs(filterGreen) <= 255)
			{
				break;
			}
			
			System.out.println("\nPlease input a value between -255 and 255.");
		}
		
		// Blue
		while (true)
		{
			System.out.print("Enter Filter's Blue Value: ");
			filterBlue = reader.nextInt();
			
			if (Math.abs(filterBlue) <= 255)
			{
				break;
			}
			
			System.out.println("\nPlease input a value between -255 and 255.");
		}
		
		// Create Filtered Image
		APImage filteredImage = image.clone();
		
		for (Pixel p : filteredImage)
		{
			// Get the pixel's RGB values
			int red = p.getRed();
			int green = p.getGreen();
			int blue = p.getBlue();
			
			// Add the filter and clamp the value 
			int newRed = red + filterRed;
			if (newRed > 255)
			{
				newRed = 255;
			}
			else if (newRed < 0)
			{
				newRed = 0;
			}
			
			int newGreen = green + filterGreen;
			if (newGreen > 255)
			{
				newGreen = 255;
			}
			else if (newGreen < 0)
			{
				newGreen = 0;
			}
				
			int newBlue = blue + filterBlue;
			if (newBlue > 255)
			{
				newBlue = 255;
			}
			else if (newBlue < 0)
			{
				newBlue = 0;
			}
			
			// Apply the new filtered RGB values
			p.setRed(newRed);
			p.setGreen(newGreen);
			p.setBlue(newBlue);
		}
		
		// Draw images
		System.out.println("\nDisplaying images...");
		image.setTitle("P-5: Before");
		image.draw();
		
		filteredImage.setTitle("P-5: After");
		filteredImage.draw();
	}
}
