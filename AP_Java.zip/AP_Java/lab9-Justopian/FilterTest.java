// Lab 9: 5-5 -- Filters
// Justin Varga

import images.*;
import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.io.*;

public class FilterTest
{
	public static void main(String[] args) throws Exception, Error
	{
		// Find Source Image File
		
		// Create Split Window
		
		
		// Take Input
		APImage image;
		String filename;
		
		JTextField filenameField = new JTextField("");
		SpinnerNumberModel redSpinner = new SpinnerNumberModel(0, -255, 255, 1);
		SpinnerNumberModel greenSpinner = new SpinnerNumberModel(0, -255, 255, 1);
		SpinnerNumberModel blueSpinner = new SpinnerNumberModel(0, -255, 255, 1);
		
		Object[] message =
		{
			"Source Image Filename: ", filenameField,
			"Filter Red: ", redSpinner,
			"Filter Green: ", greenSpinner,
			"Filter Blue: ", blueSpinner
		};
		
		int option = JOptionPane.showConfirmDialog(null, message, "Filter Settings", JOptionPane.OK_CANCEL_OPTION);
		
		if (option == JOptionPane.OK_OPTION)
		{
			if (filenameField == null)
			{
				JOptionPane.showMessageDialog(null, "Error: Must input a filename!");
			return;
			}
			
			filename = filenameField.getText();
			
			try // Does an image with that name exist?
			{
				if (!filename.endsWith(".jpg"))
				{
					filename += ".jpg";
				}
				
				image = new APImage(filename);
			}
			catch(Exception|Error err)
			{
				JOptionPane.showDialog(null, "Error: File named \"" + filename + "\" not found");
				return;
			}
		}
		else
		{
			JOptionPane.showDialog(null, "Process Cancelled");
			return;
		}
		
		int filterRed = redSpinner.getNumber();
		int filterGreen = greenSpinner.getNumber();
		int filterBlue = blueSpinner.getNumber();
		
		// Create Filtered Image
		APImage filteredImage = image.clone();
		
		for (Pixel p : filteredImage)
		{
			// Get the pixel's RGB values
			int red = p.getRed();
			int green = p.getGreen();
			int blue = p.getBlue();
			
			// Add the filter and clamp the value 
			int newRed = red + filterRed;
			if (newRed > 255)
			{
				newRed = 255;
			}
			else if (newRed < 0)
			{
				newRed = 0;
			}
			
			int newGreen = green + filterGreen;
			if (newGreen > 255)
			{
				newGreen = 255;
			}
			else if (newGreen < 0)
			{
				newGreen = 0;
			}
				
			int newBlue = blue + filterBlue;
			if (newBlue > 255)
			{
				newBlue = 255;
			}
			else if (newBlue < 0)
			{
				newBlue = 0;
			}
			
			// Apply the new filtered RGB values
			p.setRed(newRed);
			p.setGreen(newGreen);
			p.setBlue(newBlue);
		}
		
		// Draw images
		System.out.println("\nDisplaying images...");
		image.setTitle("P-5: Before");
		image.draw();
		
		filteredImage.setTitle("P-5: After");
		filteredImage.draw();
	}
}
