// Lab 9: 5-4 -- Sepia
// Justin Varga

import images.*;

public class Project4
{
	public static void main(String[] args)
	{
		// Declare Variables
		APImage image = new APImage("source.jpg");
		image.setTitle("P-4: Before");
		image.draw();
		
		APImage sepiaImg = image.clone();
		sepiaImg.setTitle("P-4: After");
		
		for (Pixel p : sepiaImg)
		{
			// Make Grayscale
			int red = p.getRed();
			int green = p.getGreen();
			int blue = p.getBlue();
			
			int average = (int)((red + green + blue) / 3.0 + 0.5);
			
			red = average;
			green = average;
			blue = average;
			
			// Make Sepia
			if (red < 63)
			{
				red = (int)(red * 1.1);
				blue = (int)(blue * 0.9);
			}
			else if (red < 192)
			{
				red = (int)(red * 1.15);
				blue = (int)(blue * 0.85);
			}
			else
			{
				red = Math.min((int)(red * 1.08), 255);
				blue = (int)(blue * 0.93);
			}
			
			p.setRed(red);
			p.setGreen(green);
			p.setBlue(blue);
		}
		
		
		// Show the sepia-ized image
		sepiaImg.draw();
	}
}
