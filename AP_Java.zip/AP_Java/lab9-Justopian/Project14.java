// Lab 9: 5-14 -- Echo
// Justin Varga

import sounds.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class Project14
{
	private static APSoundClip clip;
	
	public static String filename;
	public static final String nullFilename = "Please press \"Open\" to select a file >";
	
	public static double delayInSeconds = 0;
	public static int delay = 0; // In Samples
	
	public static double volumeDampening = 0.6;
	
	public static void main(String[] args)
	{
		// Make the controller
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setTitle("Echoes (P-14)");
		
		Container c = frame.getContentPane();
		c.setBackground(new Color(220,230,240));
		c.setLayout(new GridLayout(4, 3, 10, 10));
	
		// Row 1: Filename / Open	
		JLabel filenameLabel = new JLabel("Filename:", SwingConstants.RIGHT);
		JLabel openLabel = new JLabel(nullFilename, SwingConstants.RIGHT);
		JButton openButton = new JButton("Open");
		
		openLabel.setFont(new Font("Serif", Font.PLAIN, 12));
		
		c.add(filenameLabel);
		c.add(openLabel);
		c.add(openButton);
		
		// Row 2.1: Delay Label
		JLabel delayLabel = new JLabel("Delay (seconds):", SwingConstants.RIGHT);
		c.add(delayLabel);
		
		// Row 2.2: Delay Panel
		JTextField delayField = new JTextField("0");
		delayField.setHorizontalAlignment(JTextField.RIGHT);
		c.add(delayField);
		
		// Row 2.3: Custom Spinner (b/c the actual one was wonky)
		JPanel upDownPanel = new JPanel();
		upDownPanel.setLayout(new GridLayout(2,1,10,10));
		upDownPanel.setBackground(new Color(220,230,240));
		
		JButton upBtn = new JButton("+");
		JButton downBtn = new JButton("-");
		
		upDownPanel.add(upBtn);
		upDownPanel.add(downBtn);
		
		c.add(upDownPanel);
		
		// Row 3.1: Echo Volume Label
		JLabel volumeLabel = new JLabel("Echo Volume:", SwingConstants.RIGHT);
		c.add(volumeLabel);
		
		// Row 3.2: Echo Volume Slider
		JSlider volumeSlider = new JSlider(0, 200, 60);
		
		volumeSlider.setMajorTickSpacing(10);
		volumeSlider.setMinorTickSpacing(1);
		volumeSlider.setSnapToTicks(true);
		
		volumeSlider.setPaintTicks(true);
		
		Hashtable labelTable = new Hashtable();
		labelTable.put(0, new JLabel("0.0x"));
		labelTable.put(100, new JLabel("1.0x"));
		labelTable.put(200, new JLabel("2.0x"));
		volumeSlider.setLabelTable(labelTable);
		
		volumeSlider.setFont(new Font("Serif", Font.PLAIN, 12));
		volumeSlider.setPaintLabels(true);
		
		volumeSlider.setBackground(new Color(220,230,240));
		
		c.add(volumeSlider);
		
		// Row 3.3: Current Echo Volume
		JLabel currentVolumeLabel = new JLabel("0.60x", SwingConstants.CENTER);
		c.add(currentVolumeLabel);
		
		// Row 4: Buttons
		JButton updateButton = new JButton("Update");
		JButton playButton = new JButton("Play");
		JButton cancelButton = new JButton("Quit");
		
		c.add(updateButton);
		c.add(playButton);
		c.add(cancelButton);
		
		// Listeners
		openButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{				
				do
				{
					try
					{
						File tempFile = openFileDialog();
						filename = tempFile.getName();
					}
					catch(Error|Exception err)
					{
						JOptionPane.showConfirmDialog(null, nullFilename);
						continue;
					}
					
					setClip();
					break;
				}
				while(true);
				
				openLabel.setText(filename);
				
				// Require update
				updateButton.setEnabled(true);
				playButton.setEnabled(false);
			}
		});
		
		delayField.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				JTextField dTxt = (JTextField)e.getSource();
			
				try
				{
					delayInSeconds = Double.parseDouble(delayField.getText());
					delay = (int)Math.abs(delayInSeconds * clip.getSamplingRate());
				}
				catch(Error|Exception err)
				{
					dTxt.setText("0");
					delayInSeconds = 0;
					delay = 0;
				}
				
				playButton.setEnabled(false);
				updateButton.setEnabled(true);
			}
		});
		
		upBtn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{				
				double d;
				try
				{
					d = Double.parseDouble(delayField.getText());
					if (d + 1 > getLengthInSeconds(clip))
					{
						d = d;
					}
					else
					{
						d += 1;
					}
				}
				catch(Error|Exception err)
				{
					d = 0;
				}
				
				delayInSeconds = d;
				delay = (int)Math.abs(delayInSeconds * clip.getSamplingRate());
				delayField.setText(String.valueOf(d));
				
				playButton.setEnabled(false);
				updateButton.setEnabled(true);
			}
		});
		
		downBtn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{				
				double d;
				try
				{
					d = Double.parseDouble(delayField.getText());
					if (d - 1 < 0)
					{
						d = 0;
					}
					else
					{
						d -= 1;
					}
				}
				catch(Error|Exception err)
				{
					d = 0;
				}
				
				delayInSeconds = d;
				delay = (int)Math.abs(delayInSeconds * clip.getSamplingRate());
				delayField.setText(String.valueOf(d));
				
				playButton.setEnabled(false);
				updateButton.setEnabled(true);
			}
		});
		
		volumeSlider.addChangeListener(new ChangeListener()
		{
			public void stateChanged(ChangeEvent e)
			{
				JSlider slider = (JSlider)e.getSource();
				if (!slider.getValueIsAdjusting())
				{
					volumeDampening = (double)(slider.getValue()) / 100.0;
					String str = String.format("%.2f", volumeDampening);
					currentVolumeLabel.setText(str + "x");
				}
				else
				{
					playButton.setEnabled(false);
					updateButton.setEnabled(true);
				}
			}
		});
		
		updateButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent evt)
			{
				try
				{
					delayInSeconds = Double.parseDouble(delayField.getText());
					delay = (int)Math.abs(delayInSeconds * clip.getSamplingRate());
				}
				catch(Error|Exception err)
				{
					delayInSeconds = 0;
					delay = 0;
				}
				
				playButton.setEnabled(true);
				updateButton.setEnabled(false);
			}
		});
		
		playButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				makeEcho();
				clip.play();
			}
		});
		
		cancelButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				System.exit(0);
			}
		});
		
		// Finalize the frame
		playButton.setEnabled(false);
		updateButton.setEnabled(false);
		
		frame.pack();
		frame.setVisible(true);
	}
	
	public static void setClip()
	{
		setClip(filename);	
	}
	
	public static void setClip(String fn)
	{
		try
		{
			clip = new APSoundClip(fn);
		}
		catch(Error|Exception err)
		{
			clip = new APSoundClip(1);
		}
	}
	
	public static int getLengthInSeconds(APSoundClip sc)
	{
		int l;
		
		try
		{
			l = sc.getLength() / sc.getSamplingRate();
		}
		catch(Error|Exception err)
		{
			l = getLengthInSeconds(new APSoundClip(1));
		}
		
		return l;
	}
	
	public static void makeEcho()
	{
		// Create Sound Objects
		setClip();
		APSoundClip echoedClip = clip.clone();
		
		// Combine Clips With Delay
		for (int i = delay ; i < clip.getLength() ; i++)
		{
			Sample sampleAtDelay = clip.getSample(i);
			Sample originalSample = clip.getSample(i - delay);
			
			// Prevent Overflow / Underflow
			int newValue = (int)(volumeDampening * originalSample.getValue() + sampleAtDelay.getValue());
			
			if (newValue > Sample.MAX_VALUE)
			{
				newValue = Sample.MAX_VALUE;
			}
			else if (newValue < Sample.MIN_VALUE)
			{
				newValue = Sample.MIN_VALUE;
			}
			
			// Build On New Song
			Sample newSample = new Sample(newValue);
			echoedClip.setSample(i, newSample);
		}
		clip = echoedClip.clone();
	}

	public static File openFileDialog()
	{
		JFileChooser chooser = new JFileChooser();
		chooser.setFileFilter(new SoundFileFilter(".wav", "WAV sounds (*.wav)"));
		int result = chooser.showOpenDialog(null);
		if (result == JFileChooser.CANCEL_OPTION)
		{
			return null;
		}
		else
		{
			try
			{
				File file = chooser.getSelectedFile();
				return file;
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(null, e.toString());
			}
		}
		return null;
	}
}

