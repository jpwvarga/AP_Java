package components;

import javax.swing.event.*;
import javax.swing.*;
import java.util.*;
import java.awt.*;

public enum RGBEnum
{
	RED, GREEN, BLUE;
}

public class FilterFrame extends JPanel
{
	public FilterFrame(JSpinner[] spinners, JPanel previewPanel)
	{
		super(new SpringLayout());
		
		String[] labels = {"Red: ", "Green: ", "Blue: "};
		int numPairs = labels.length;
		
		JPanel previewWindow = addLabeledPanel(this, "Filter Preview: ");
		
		for (int i = 0 ; i < numPairs ; i++)
		{
			JSpinner spinner = addLabeledSpinner(this, labels[i], new RGBModel((int)spinners[i].getValue(), RGBEnum[i], previewWindow));
			spinner.setEditor(new RGBEditor(spinner, previewWindow));
		}
		
		SpringUtilities.makeCompactGrid(this, numPairs, 2, 10, 10, 5, 10);
	}
	
	static protected JSpinner addLabeledSpinner(Container c, String label, SpinnerModel model)
	{
		JLabel l = new JLabel(label);
		c.add(l);
		
		JSpinner spinner = new JSpinner(model);
		l.setLabelFor(spinner);
		c.add(spinner);
		
		return spinner;
	}
	
	static protected JPanel addLabeledPanel(Container c, String label)
	{
		JLabel l = new JLabel(label);
		c.add(l);
		
		JPanel panel = new JPanel();
		panel.setPreferredSize(30, 30);
		panel.setBackground(Color.BLACK);
		
		l.setLabelFor(panel);
		c.add(panel);
		
		return spinner;
	}
	
	private static void createAndShowGUI()
	{
		JFrame frame = new JFrame("RGB Test Example");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JComponent newContentPane = new FilterFrame();
		newContentPane.setOpaque(true);
		frame.setContentPane(newContentPane);
		
		frame.pack();
		frame.setVisible(true);
	}
	
	public static void main(String[] args)
	{
		SwingUtilities.invokeLater(new Runnable()
		{
			public void run()
			{
				UIManager.put("swing.boldMetal", Boolean.FALSE);
				createAndShowGUI();
			}
		});
	}
}

public class RGBModel extends SpinnerNumberModel
{	
	final int COMP_MIN = -255;
	final int COMP_MAX = 255;
	final int COMP_STEP = 1;
	public RGBEnum comp;
	public JPanel previewPanel;
	
	public RGBModel(int value, RGBEnum component, JPanel pvp)
	{
		comp = component;
		previewPanel = pvp;
		super(value, COMPONENT_MIN, COMPONENT_MAX, COMPONENT_STEP);
	}
	
	public int getIntValue()
	{
		return (int)getValue();
	}
	
	public Color getPreviewColor()
	{
		return previewPanel.getBackground();
	}
	
	public void setPreviewColor(Color c)
	{
		previewPanel.setBackground(c);
	}
		
	public Color makeFilter(int value)
	{
		Color currentColor = getPreviewColor();
		
		int filterRed = currentColor.getRed();
		int filterGreen = currentColor.getGreen();
		int filterBlue = currentColor.getBlue();
		
		switch(comp)
		{
			case RED:
				filterRed += value;
				
				if (Math.abs(filterRed) > 255)
				{
					filterRed = Math.signum(filterRed) * 255;
				}
				
				break;
				
			case GREEN:
				filterGreen += value;
				
				if (Math.abs(filterGreen) > 255)
				{
					filterRed = Math.signum(filterGreen) * 255;
				}
				break;
				
			case BLUE:
				filterBlue += value;
				
				if (Math.abs(filterBlue) > 255)
				{
					filterRed = Math.signum(filterBlue) * 255;
				}
				break;
				
			default:
				break;
		}
		
		return new Color(filterRed, filterGreen, filterBlue);
		
	}
}

public class RGBEditor extends JLabel implements ChangeListener
{
	public RGBEditor(JSpinner spinner, JPanel preview)
	{
		setOpaque(true);
		
		// Get info from the model
		RGBModel myModel = (RGBModel)(spinner.getModel());
		spinner.addChangeListener(this);
		
		updateTooltipText(spinner);
		
		// Set size info
		Dimension size = new Dimension(30, 30);
		setMinimumSize(size);
		setPreferredSize(size);
	}
	
	protected void updateTooltipText(JSpinner spinner)
	{
		String tooltipText = spinner.getToolTipText();
		if (tooltipText != null)
		{
			if (!tooltipText.equals(getToolTipText()))
			{
				setToolTipText(tooltipText);
			}
		}
		else
		{
			RGBModel myModel = (RGBModel)(spinner.getModel());
			int value = myModel.getIntValue();
			setToolTipText("\"" + value + "\"");
		}
	}
	
	public void stateChanged(ChangeEvent e)
	{
		JSpinner mySpinner = (JSpinner)(e.getSource());
		RGBModel myModel = (RGBModel)(spinner.getModel());
		myModel.setPreviewColor(myModel.getIntValue());
		updateTooltipText(mySpinner);
	}
}
