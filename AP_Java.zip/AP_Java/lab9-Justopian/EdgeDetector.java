import images.*;

public class EdgeDetector
{
	public static void main(String[] args) throws ArrayIndexOutOfBoundsException
	{
		final int threshold = 10;
		APImage image = new APImage("source.jpg");
		image.setTitle("Source Image");
		image.draw();
		
		APImage edgeImage = image.clone();  //note     APImage edgeImage = image    will NOT WORK, results in two variables pointing to the same object, you want two seperate objects!
		
		//Do a row major traversal, compare the RGB average of each pixel to its left and bottom neighbors, if less than threshold, make pixel white
		
		Pixel whitePixel = new Pixel(255, 255, 255);
		Pixel blackPixel = new Pixel(0, 0, 0);
		
		for (int row = 0 ; row < image.getHeight() - 1 ; row++)
		{
			for (int col = 1 ; col < image.getWidth() ; col++)
			{
				Pixel currentPixel = image.getPixel(col, row);
				Pixel leftPixel = image.getPixel(col - 1, row);
				Pixel downPixel = image.getPixel(col, row + 1);
				
				int cR = currentPixel.getRed();
				int cG = currentPixel.getGreen();
				int cB = currentPixel.getBlue();
				
				int lR = leftPixel.getRed();
				int lG = leftPixel.getGreen();
				int lB = leftPixel.getBlue();
				
				int dR = downPixel.getRed();
				int dG = downPixel.getGreen();
				int dB = downPixel.getBlue();
				
				int currentAverage = (cR + cG + cB) / 3;
				int leftAverage = (lR + lG + lB) / 3;
				int downAverage = (dR + dG + dB) / 3;
				
				if (Math.abs(currentAverage - leftAverage) < threshold || Math.abs(currentAverage - downAverage) < threshold)
				{
					edgeImage.setPixel(col, row, whitePixel.clone());
				}
				else
				{
					edgeImage.setPixel(col, row, blackPixel.clone());
				}
			}
		}
		
		edgeImage.setTitle("Edges");
		edgeImage.draw();
	}
}
