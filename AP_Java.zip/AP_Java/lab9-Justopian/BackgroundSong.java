import sounds.*;
import javax.swing.JOptionPane;

public class BackgroundSong
{
	public static void main(String[] args)
	{
		// Take File Input
		String foregroundFile = JOptionPane.showInputDialog("Enter foreground song filename:", "");
		String backgroundFile = JOptionPane.showInputDialog("Enter background song filename:", "");
		
		// Create Sound Objects
		APSoundClip foregroundSong = new APSoundClip(foregroundFile); 
		APSoundClip backgroundSong = new APSoundClip(backgroundFile); 
		
		// Create New Sound Clips
		APSoundClip newSong = new APSoundClip(foregroundSong.getLength());
		
		// Combine Clips
		for (int i = 0 ; i < foregroundSong.getLength() ; i++)
		{
			Sample fgSample = foregroundSong.getSample(i);
			Sample bgSample;
			if (i < backgroundSong.getLength())
			{
				bgSample = backgroundSong.getSample(i);
			}
			else
			{
				bgSample = new Sample(0);
			}
			
			// Prevent Overflow / Underflow
			int newValue = fgSample.getValue() + bgSample.getValue();
			if (newValue > Sample.MAX_VALUE)
			{
				newValue = Sample.MAX_VALUE;
			}
			else if (newValue < Sample.MIN_VALUE)
			{
				newValue = Sample.MIN_VALUE;
			}
			
			// Build On New Song
			Sample newSample = new Sample(newValue);
			newSong.setSample(i, newSample);
		}
		
		// Play Song
		newSong.play();
	}
}
