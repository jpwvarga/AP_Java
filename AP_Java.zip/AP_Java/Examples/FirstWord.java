// Example : First Word
// Justin Varga

// To test out the String class's methods

import java.util.Scanner;

public class FirstWord
{
	public static void main(String[] args)
	{
		Scanner reader = new Scanner(System.in);
		
		System.out.print("Please enter a sentence: ");
		String sentence = reader.nextLine();
		
		String firstWord = "";
		
		/*for (char c : sentence)
		{
			if (c == ' ' || c == ',' || c == '.' || c == '?' || c =='!' )) break;

			firstWord += c;
		}*/
		
		for (int i = 0 ; i < sentence.length() ; i++)
		{
			// Get the character at the given index
			char c = sentence.charAt(i);
			
			// Test the delimiters
			if(c == ' ' || c == ',' || c == '.' || c == '?' || c == '!')	
			{
				// Exit loop if word ends
				break;
			}
			
			firstWord += sentence.charAt(i);
		}
		
		System.out.println("The word is \"" + firstWord + "\"");
	}	
}
