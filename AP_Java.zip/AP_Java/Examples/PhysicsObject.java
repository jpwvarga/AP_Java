import java.util.Scanner;

public class PhysicsObject
{
	public static void main(String[] args)
	{
		//Declare constants ... why are constants important for "safe" programming?
		final double PI = 3.14159; // "final" declares a constant. Capitalize constants.
		final String PIE = "Apple"; // Constants are immutable (can not be changed)

		//Take input
		Scanner reader = new Scanner(System.in);
		System.out.println("Enter the mass of the object: ");
		double mass = reader.nextDouble();
		System.out.println("Enter the initial velocity of the object: ");
		int velocity = reader.nextDouble().toInt();
		System.out.println("Enter the acceleration of the object: ");
		double acceleration = reader.nextDouble();
		System.out.println("Enter the time the object moves for: ");
		double time = reader.nextDouble();

		//Calculate
		double momentum = mass * velocity;
		double kineticEnergy = 0.5f * mass * (velocity * velocity);  //Syntax: Rules for combining words and symbols into statements
		double distance = velocity * time + 0.5 * acceleration * time * time;  //Semantics: rules for interpreting statements

		//Add Output Code Here
		System.out.println("\np₀ = " + momentum);
		System.out.println("K₀ = " + kineticEnergy);
		System.out.println("d = " + distance);
	}
}

/*Try the following to see what complier errors you get (fix each error before introducing the next one):
	1. Remove the opening { in the main method
	2. Remove the closing } in the main method
	3. Introduce a spelling error in a variable in one of the calculate statements
	4. If time, see what other errors you can cause!  See if you can make sense of what the compiler error messages are trying to tell you.
*/
