// Manages student data: name and test scores
package students;

public class Student
{
	// Constants (unchanging)
	
	// Instance properties -> properties of THIS object (differ between objects)
	private String name;
	private int[] scores;
	
	// ----- Constructors ----- //
	public Student()
	{
		this("", new int[] {0, 0, 0});
	}
	
	public Student(String n, int[] pts)
	{
		name = n;
		scores = pts;
	}
	
	private Student(Student s)
	{	
		this(s.getName(), s.getScores());
	}
	
	// ----- Methods ----- //
	public void setName(String aString) // Setter for student's name
	{
		name = aString;
	}
	
	public String getName() // Getter for student's name
	{
		return name;
	}
	
	public void setScore(int whichTest, int testScore)
	{
		scores[whichTest] = testScore;
	}
	
	public int getScore(int whichTest)
	{
		return scores[whichTest] | scores[scores.length - 1];
	}
	
	public int[] getScores()
	{
		int[] allScores = new int[scores.length];
		
		for (int i = 0 ; i < scores.length ; i++)
		{
			allScores[i] = Integer.valueOf(scores[i]);
		}
		
		return allScores;
	}
	
	public int getAverage()
	{
		int average = 0;
		
		for (int score : scores)
		{
			average += score;
		}
		
		average /= scores.length;
		
		return average;
	}
	
	public int getHighScore()
	{
		int highScore = scores[0];
		
		for (int score : scores)
		{
			if (score > highScore)
			{
				highScore = score;
			}
		}
		
		return highScore;
	}
	
	public String toString()
	{
		String displayStr = "Student: " + name;
		
		for (int i = 0 ; i < scores.length ; i++)
		{
			displayStr += "\nScore " + i + ": " + scores[i];
		}
		
		return displayStr;
	}
	
	public Student copy()
	{
		return new Student(this);
	}
	
}
