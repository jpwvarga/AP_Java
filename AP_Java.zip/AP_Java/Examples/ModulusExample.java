// Ch. 3 Examples: Modulus Example
// Justin Varga

import java.util.Scanner;

public class ModulusExample
{
	public static void main(String[] args)
	{
		Scanner reader = new Scanner(System.in);
		int militaryHours, minutes;
		int standardHours;
		String amOrPM, minuteString;
		
		System.out.println("Input military hours:");
		militaryHours = reader.nextInt();
		
		System.out.println("Input minutes:");
		minutes = reader.nextInt();
		
		if (militaryHours > 12)
		{
			amOrPM = "PM";
		}
		else
		{
			amOrPM = "AM";
		}
		
		standardHours = militaryHours % 12;
		
		if (minuteString.length < 2)
		{
			minuteString = "0" + int.toString(minutes);
		}
		else
		{
			minuteString = int.toString(minutes);
		}
		
		System.out.println(militaryHours + ":" + minuteString + " in standard time:");
		System.out.println(standardHours + ":" + minuteString + " " + amOrPM);
	}
}
