// Compares students

package students;
import students.*;
import java.util.Scanner;

public class StudentComparer
{
	static public void main(String[] args)
	{
		// Create Students
		Student[] students = new Student[args.length];
		
		for (int i = 0 ; i < args.length ; i++)
		{
			students[i] = new Student(args[i]);
		}
		
		final int n = students.length;
		
		// Which Student has the highest grade?
		String highScores = "";
		String highestScoreIndexString = "";
		
		try
		{
			for (int i = 0 ; i < n ; i++)
			{
				highScores += students[i].getHighScore() + "\n";
			}
		}
		catch(Error|Exception err)
		{
			System.out.println(err.message);
		}
		
		Scanner reader = new Scanner(highScores);
		int[] scores;
		
		for(int line = 0 ; reader.hasNextInt() ; line++)
		{
			scores[i] = reader.nextInt();
			
			if (i - 1 > 0)
			{
				scores[i - 1]);
			}
		}
		
		
		// What is the highest grade?
		
		// Which has highest average?
		
	}
}
