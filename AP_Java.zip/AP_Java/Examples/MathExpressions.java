import java.util.Scanner;

public class MathExpressions
{
	public static void main(String[] args)
	{
		//Take input
		double numberOne = -7;
		float numberTwo = -3;

		//Output Results
		System.out.println(numberOne + " / " + numberTwo + " = " + numberOne / numberTwo);
		System.out.println(numberOne + " % " + numberTwo + " = " + numberOne % numberTwo);
		
	}
}

/*Try the following to see what complier errors you get (fix each error before introducing the next one):
	1. Switch the ints to floats, how do things change?
	2. Try some different numbers to figure out what the % operator is doing.  This is the modulus operator.
	3. Try some negative numbers.

	Review pages 66 & 67, we will discuss once everyone is ready
*/
