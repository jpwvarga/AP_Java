import java.util.Scanner;

public class stringThings
{
	public static void main(String[] args)
	{
		//note that String does not turn blue
		//String is actually a non-primitive type
		String awesomeString = "Stevie S. Hampton";
		System.out.println("The length of \"" + awesomeString + "\" is " + awesomeString.length());
		
		Scanner scanner = new Scanner(System.in);
		
		String firstName, lastName, fullName;
		System.out.print("\nFirst Name: ");
		firstName = scanner.next();
		
		System.out.print("Last Name: ");
		lastName = scanner.next();
		
		fullName = firstName + " " + lastName;
		
		System.out.println("\nWelcome back, " + fullName + "!");
		
		int a = 5;
		int b = 7;
		String c = "The number is ";
		
		// Order of operations cast each + individually, so String + int and int + String = String, but int + int + String = int + String
		System.out.println(c + a + b);
		System.out.println(c + (a + b));
		
		System.out.println("Commands: \n n \\ backslash \" \t t");
	}
}
