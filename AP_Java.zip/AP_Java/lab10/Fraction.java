// Lab 10 : Fraction

import java.lang.Math;

public class Fraction
{
	private int numerator, denonminator;
	
	public Fraction()
	{
		this(null, null);
	}
	
	public Fraction(int n, int d)
	{
		numerator = n;
		denominator = d;
		simplify();
	}
	
	public int getNumerator()
	{
		return numerator;
	}
	
	public void setNumerator(int n)
	{
		numerator = n;
	}
	
	public int getDenominator()
	{
		return denominator;
	}
	
	public void setDenominator(int d)
	{
		denominator = d;
	}
	
	public Fraction add(Fraction secondFraction)
	{
		getCommonDenominators(this, secondFraction);
		setNumerator(getNumerator() + secondFraction.getNumerator());
		simplify();
	}
	
	public Fraction simplify()
	{
		// Check for null or undefined
		if (getDenominator().equals(0) || getDenominator().equals(null))
			return null;
			
		// Proceed regularly
		while (numerator % denominator)
		{
			
		}
		
	}
	
	private Fraction format()
	{
		
	}
	
	private void getCommonDenominators(Fraction f1, Fraction f2)
	{
		f1.setNumerator(f1.getNumerator() * f2.getDemoninator());
		f1.setDenominator(f1.getDenominator() * f2.getDemoninator());
		
		f2.setNumerator(f2.getNumerator() * f1.getDemoninator());
		f2.setDenominator(f2.getDenominator() * f1.getDemoninator());
	}
	
	public String toString()
	{
		String str = String.format();
		return ;
	}
	
}
