# lab8-Justopian
lab8-Justopian created by GitHub Classroom

GridDouble is my test for having one dialogue box but multiple inputs
   (It works!)
