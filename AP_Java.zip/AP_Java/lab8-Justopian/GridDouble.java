// Lab 8: Examples 4-11 and 4-12
// Justin Varga

import java.util.*;
import java.awt.*;
import javax.swing.*;

public class GridDouble
{
	public static void main(String[] args)
	{		
		// Take Input
		JTextField inputRows = new JTextField("8");
		JTextField inputCols = new JTextField("8");
		
		Object[] message =
		{
			"Enter number of rows: ", inputRows,
			"Enter number of columns: ", inputCols
		};
		
		int option = JOptionPane.showConfirmDialog(null, message, "Grid Inputs", JOptionPane.OK_CANCEL_OPTION);
	
		if (option == JOptionPane.OK_OPTION)
		{
			if (inputRows == null || inputCols == null || 
				inputRows.getText().equals("0") || inputCols.getText().equals("0"))
			{
				JOptionPane.showMessageDialog(null, "Error: Must have at least one row and column");
			return;
			}
		}
		else
		{
			JOptionPane.showMessageDialog(null, "Process Cancelled");
			return;
		}
		
		int rows = Integer.parseInt(inputRows.getText());		
		int cols = Integer.parseInt(inputCols.getText());
		
		// Establish Frame
		JFrame theGUI = new JFrame();
		theGUI.setTitle("Grid");
		theGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container pane = theGUI.getContentPane();
		pane.setLayout(new GridLayout(rows,cols));
		
		// Add panels to the frame
		for (int c = 0 ; c < cols ; c++)
		{	
			for (int r = 0 ; r < rows ; r++)
			{
				// Establish panel
				JPanel panel = new JPanel();
				
				int width = cols * cols / 16;
				int height = rows * rows / 16;
				
				if (width * height < 14400)
				{
					width = 120;
					height = 120;
				}
				else if (width * height > 90000)
				{
					width = 300;
					height = 300;
				}
				
				panel.setPreferredSize(new Dimension(width, height));
				
				// Color panel
				Color color;
				
				if ((r % 2 == 0 && c % 2 != 0) || 
					(r % 2 != 0 && c % 2 == 0))
				{
					color = Color.red;
				}
				else
				{
					color = Color.black;
				}
				
				panel.setBackground(color);
				
				// Add panel
				pane.add(panel);
			}
		}
		
		// Display art
		theGUI.pack();
		theGUI.setVisible(true);
	}
}
