// Lab 8: Leap Year
// Justin Varga

// Intent
/*
	To find all of the leap years in a given (restricted) range
*/

import java.io.*;
import java.util.*;

public class LeapYear
{
	public static void main(String[] args) throws IOException
	{
		// Declare Variables
		Scanner reader = new Scanner(new File("years.txt"));
		PrintWriter writer = new PrintWriter(new File("leap.txt"));
		
		while (reader.hasNext())
		{
			// Declare local variables
			int year;
			boolean isLeap = false;
			
			// Read Input
			String entry = reader.next();
			
			// Test if valid
			try
			{		
				year = Integer.valueOf(entry);
			}
			catch (Exception e)
			{
				writer.println(entry + " is NOT VALID");
				continue;
			}
						
			// Check Conditions
			if (year >= 1600 && year <= 5000) // Check if 'year' is within the range
			{
				if (year % 4 == 0 && year % 100 != 0) // Check if leap year
				{
					// Year is a leap year
					isLeap = true;
				}
				else if (year % 100 == 0 && year % 400 == 0)
				{
					// Year is a leap year
					isLeap = true;
				}
				else
				{
					// Year is NOT a leap year
					isLeap = false;
				}
			}
			else
			{
				writer.println(year + " is OUTSIDE RANGE");
				continue;
			}
			
			if (isLeap)
			{
				writer.println(year + " is a leap year");
			}
			else
			{
				writer.println(year + " is NOT a leap year");
			}
		}
		
		// Finalize Code
		System.out.println("\nLeap years have been output to leap.txt");
		reader.close();
		writer.close();
	}		
}
