// Lab 8: Number Generator
// Justin Varga

// Intent
/*
	Ask the user how many numbers they want (n) AND what maximum number size they want (maxSize)
	Generate a list of n random numbers ranging from negative maxSize to positive maxSize (excl.)
*/

import java.io.*; // Input / Output
import java.util.*; // Scanner & Random

public class NumberGenerator
{
	public static void main(String[] args) throws IOException
	{
		// Declare Variables
		Scanner reader = new Scanner(System.in);
		PrintWriter writer = new PrintWriter(new File("numbers.txt"));
		Random rand = new Random();
		
		int n = -1;
		int maxSize = -1;
		
		// Take input
		
		//// n
		while (true)
		{
			// Declare local variables
			String entry;
			int value;

			// Prompt Input
			System.out.print("Enter the count of numbers to generate: ");
			entry = reader.next();
			
			// Test if valid (restricted by Scanner)
			try
			{
				value = Integer.valueOf(entry);
			}
			catch (Exception e)
			{
				System.out.println("\n" + entry + " is not a valid number.\nPlease enter a valid number.\n");
				continue;
			}
			
			// Test conditions (specified by lab)
			if (value > 0 && value < 1000000000)
			{
				n = value;
				break;
			}
			else
			{
				System.out.println("\n" + value + " is not a valid number.\nPlease enter a number between 0 and 1,000,000,000.\n");
				continue;
			}
		}
		
		//// maxSize
		while (true)
		{
			// Declare local variables
			String entry;
			int value;

			// Prompt Input
			System.out.print("Enter the maximum magnitude of the generated numbers (+ or -): ");
			entry = reader.next();
			
			// Test if valid (restricted by Scanner)
			try
			{
				value = Integer.valueOf(entry);
			}
			catch (Exception e)
			{
				System.out.println("\n" + entry + " is not a valid number.\nPlease enter a valid number.\n");
				continue;
			}
			
			// Test conditions (specified by lab)
			if (value >= 0 && value < 10000)
			{
				maxSize = value;
				break;
			}
			else if (value >= -10000 && value < 0)
			{
				maxSize = -value;
				break;
			}
			else
			{
				System.out.println("\n" + value + " is not a valid number.\nPlease enter a number between -10,000 and 10,000.\n");
				continue;
			}
		}
		
		// Generate random numbers
		for (int i = 0 ; i < n ; i++)
		{
			// Generate number
			int number = rand.nextInt(maxSize);

			// Make it negative?
			boolean isNegative = rand.nextBoolean();
			
			if (isNegative)
			{
				number *= -1;
			}
			
			// Add to numbers.txt
			writer.println(number);
		}
		
		// Close PrintWriter
		writer.close();
		
		// Display Completion Message
		System.out.println("\nYour " + n  + " random numbers have been generated.");
	}
}
