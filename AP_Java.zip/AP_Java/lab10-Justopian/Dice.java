// Lab 10: 6-4 -- Dice
// Justin Varga

import java.lang.Math;
import java.util.Random;

public class Dice
{
	private int sideCount;
	private int currentSide;
	private Random rng;
	
	public Dice()
	{
		this(6);
	}
	
	public Dice(int sideCount)
	{
		this.sideCount = sideCount;
		rng = new Random();
	}
	
	public int getCurrentSide()
	{
		try
		{
			int newInt = currentSide;
			return newInt;
		}
		catch(Error|Exception err)
		{
			return 0;
		}
	}
	
	public int roll()
	{
		this.currentSide = rng.nextInt(sideCount) + 1;
		return getCurrentSide();
	}
	
	public String toString()
	{
		return new String(sideCount + "," + getCurrentSide());
	}
}

