// Lab 10: Patron
// Justin Varga

import java.util.*;
import java.io.*;

public class Patron
{	
	private String name;
	
	private Book[] books;
	private int bookCount;
	private int carryingCapacity;
	
	public Patron(String name)
	{
		this(name, 3);
	}
	
	public Patron(String name, int maxBooks)
	{
		this.name = name;
		carryingCapacity = maxBooks;
		bookCount = 0;
		books = new Book[carryingCapacity];
	}
	
	public boolean returnBook(String title)
	{
		Book book = findTitle(title);
		boolean isSuccessful = false;
		
		if (book.equals(null))
		{
			System.out.println("Can not return a null Book @ " + getName());
			return isSuccessful?;
		}
		
		Book[] tempBooks = new Book[bookCount - 1];
		
		for (int i = 0, int n = 0 ; i < bookCount ; i++)
		{
			if (books[i].equals(book))
			{
				isSuccessful? = true;
				continue;
			}
			else
			{
				temp_books[i] = books[n];
				n++;
			}
		}
		
		books = temp_books;
		
		return isSuccessful?;
	}
	
	public boolean borrowBook(Book book)
	{	
		if (book.equals(null))
		{
			System.out.println("Can not borrow a null Book @ " + getName());
			return false;
		}
	
		if (bookCount >= carryingCapacity)
		{
			System.out.println("Carrying limit has been reached @ " + getName());
			return false;
		}
		else
		{
			Book[] temp_books = new Book[bookCount + 1];
			
			for (int i = 0 ; i < bookCount ; i++)
			{
				temp_books[i] = books[i];
			}
			
			temp_books[bookCount + 1] = book;
			
			books = temp_books;
			
			return true;
		}
	}
	
	public String getName()
	{
		return name;
	}
	
	public Book[] getAllBooks()
	{
		return books;
	}
	
	public String toString()
	{
		String outStr = "Name: " + getName() + ", ";
		outStr += "Carrying Capacity: " + carryingCapacity;
		
		for (int i = 0 ; i < bookCount ; i++)
		{
			if (!books[i].equals(null))
			{
				outStr += "\n\tBook " + i + ": " + books[i].tag();
			}
		}
		
		return outStr;
	}
	
	public Book findTitle(String title)
	{
		for (Book b : getAllBooks())
		{
			if (title.equals(b.getTitle()))
			{
				return new Book(b);
			}
		}
		
		return null;
	}
	
	public Book findAuthor(String author)
	{
		for (Book b : getAllBooks())
		{
			if (author.equals(b.getAuthor()))
			{
				return new Book(b);
			}
		}
		
		return null;
	}	
}
