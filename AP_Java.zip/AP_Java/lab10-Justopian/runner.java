// Lab 10: Test Cases
// Justin Varga

public class runner
{
	public static void main(String[] args)
	{	
		System.out.println("\nFractions\n");
		
		int[] testFracVal = {-4, -1, 0, 2, 3, 5, 9, 18};
		
		for (int i = 0 ; ; i++)
		{
			for (int n = 0 ; ; n++)
			{
				Fraction frac = new Fraction(testFracVal[i], testFracVal[n]);
				int newN = (n + 2) % testFracVal.length;
				Fraction frac2 = new Fraction(testFracVal[i], testFracVal[newN]);
				String str = frac.toString() + " + " + frac2.toString();
				frac.add(frac2);
				str += " = " + frac.toString();
				System.out.println(str);
			}
		}
		
		System.out.println("\nDice\n");
		
		Dice d1 = new Dice();
		Dice d2 = new Dice(2);
		
		int[] rolls = {0, 0, 0, 0, 0, 0};
		
		for (int i = 100 ; i > 0 ; i--)
		{
			int roll = d1.roll();
			int roll2 = d2.roll();
			
			rolls[roll - 1]++;
			rolls[roll2 - 1]++;
		}
		
		for (int i = 0 ; i < rolls.length ; i++)
		{
			System.out.println(i + 1 + "'s: " + rolls[i]);
		}
		
		System.out.println(d1.toString() + " :: " + d2.toString());
	}
}
