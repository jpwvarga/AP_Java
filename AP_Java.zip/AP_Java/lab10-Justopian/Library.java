//Library Circulation Desk Program
//ver 1.1

import java.io.*;
import java.util.Scanner;

public class Library
{
	//Note the use of static means that we don't need to create a library object, everything can run straight from the class (common in a "runner" program)
	private static Patron patrons[];
	private static int patrons_size;
	private static Patron currentPatron;
	
	public static void main(String[] args)  throws IOException
	{
		Scanner reader = new Scanner(System.in);
		loadPatrons();
		currentPatron = selectPatron();
				
		//begin input loop
		boolean notDone = true;  //flag variable to know when to quit
		while(notDone)
		{
			System.out.println("\n------------ MAIN MENU ----------------");
			System.out.println("The current patron is " + currentPatron.getName());
			System.out.println("What would you like to do? (enter number)");
			System.out.println("1. Check Out A Book");
			System.out.println("2. Check In A Book");
			System.out.println("3. See if Book is in Library");
			System.out.println("4. Change Patron");
			System.out.println("5. EXIT");
			int input = reader.nextInt();

			switch (input){
				case 1:
					checkOut();
					break;
				case 2:
					checkIn();
					break;
				case 3:
					if(getBook() != null)
					{
						System.out.println("We have it!");
					}
					else
					{
						System.out.println("Sorry, we don't have that book :(");
					}
					break;
				case 4:
					currentPatron = selectPatron();
					break;
				case 5:
					System.out.println("Have a nice day!");
					notDone = false;
					break;
				default:
					System.out.println("Invalid selection!");
			}

		}
	}
	
	
	//This method loads patrons from a patrons.txt file by creating objects for each of them and storing them in an array.
	//We will learn about arrays in chapter 10.  For now all you need to know is that you can think of an array as a list of things.
	//In most applications we would manage patrons using a database, but that is beyond the scope of this course (the curious can
	//find more here: https://www.javaworld.com/article/3388036/what-is-jdbc-introduction-to-java-database-connectivity.html)
	
	private static void loadPatrons() throws IOException
	{
		patrons = new Patron[10]; //assumes a max of ten patron names in the patrons.txt file
		patrons_size = 0;
		Scanner fileReader = new Scanner(new File("patrons.txt"));
		int i = 0;  //index counter
		while(fileReader.hasNext())
		{
			patrons_size++;  //keep track of # of elements in array
			patrons[i] = new Patron(fileReader.nextLine());
			i++;

			if(patrons_size >= 10)
			{
				break;  //avoid index out of bounds, array only has 10 spots
			}
		}
	}
	
	
	//This method checks books.txt to see if book exists in the library and returns it (as a Book object) if it does,
	//otherwise returns null (no value).  Note that this is an "expensive" operation to be checking against the file on
	//disk every time.  In reality we would load the contents of this file into a database or array and cache some of it
	//in memory to make searching faster (for now, though, wanted to stick with code you know).  Also this libary does NOT
	//keep track of which books are currently checked out or how many copies of each book the library has.  This could be
	//implemented by an int copiesAvaialable instance variable that is decremented when a book is checked out and incremented
	//when it is returned.  If the copiesAvailable == 0 then that means that title is all checked out and not available.
	
	private static Book getBook() throws IOException
	{
		Scanner reader = new Scanner(System.in);
		System.out.print("Enter name of book: ");
		String title = reader.nextLine();
		Scanner fileReader = new Scanner(new File("books.txt")); //Note: books.txt is formatted title-author in two line increments (the return character is the delimiter)
		while(fileReader.hasNext())
		{
			String currentTitle = fileReader.nextLine();
			String currentAuthor = fileReader.nextLine();
			if(currentTitle.equals(title))  //if book title found, create the book object and return it
			{
				return new Book(currentTitle, currentAuthor);
			}
		}
		return null;  //if we get done with the book list and did not find the book then return null
	}

	//Displays available patrons and returns selected patron object
	private static Patron selectPatron() throws IOException
	{
		Scanner reader = new Scanner(System.in);
		while(true)
		{
			System.out.println("The following patrons are in the system, which would you like (enter number)?");
			for (int i = 0; i < patrons_size; i++)  //iterate over the array, printing out names
			{
				System.out.println(i + ": " + patrons[i].getName());
			}
			int input = reader.nextInt();
			if (input >= 0 && input < patrons_size)
			{
				return patrons[input];
			}
			else
			{
				System.out.println("Invalid Entry");
			}
		}
	}

	private static void checkOut() throws IOException
	{
		//IMPLEMENT THIS METHOD - See explination in the Lab 10 Assignment
		//Remember that the class variable currentPatron refrences the patron object you should work with
		currentPatron = selectPatron();
		Book givenBook = getBook();
		
		if ()
		{
			
		}
		
		try
		{
			currentPatron.giveBook(givenBook);
		}
		catch(Error|Exception err)
		{
			throw err;
		}
		
	}

	private static void checkIn() throws IOException
	{
		//IMPLEMENT THIS METHOD - See explination in the Lab 10 Assignment
		//Remember that the class variable currentPatron refrences the patron object you should work with
	}

}
