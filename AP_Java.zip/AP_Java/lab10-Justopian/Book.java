// Lab 10: Book
// Justin Varga

import java.io.*;
import java.util.*;

public class Book
{
	private String title, author;

	public Book(String title, String author)
	{	
		if (title.equals(null))
		{
			title = "";
			System.out.println("BOOK ERROR: null title!");
		}
		else
		{
			this.title = title;
		}
		
		if (author.equals(null))
		{
			author = "";
			System.out.println("BOOK ERROR: null author!");
		}
		else
		{
			this.author = author;
		}
	}
	
	public String getAuthor()
	{
		return author;
	}
	
	public String getTitle()
	{
		return title;
	}
	
	public String toString()
	{
		return title + ", " + author + "\n" + file.getName();
	}
}
