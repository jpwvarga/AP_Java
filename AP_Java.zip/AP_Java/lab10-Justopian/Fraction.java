// Lab 10: Fraction
// Justin Varga

import java.lang.Math;

public class Fraction
{
	private int numerator, denominator;
	
	public Fraction(int numerator, int denominator)
	{	
		int newNum = numerator;
		int newDen = denominator;
	
		if (denominator < 0)
		{
			newDen *= -1;
			newNum *= -1;
		}
		
		this.numerator = newNum;
		this.denominator = newDen;
	}
	
	public Fraction(Fraction frac)
	{
		this(frac.getNumerator(), frac.getDenominator());
	}
	
	public int getNumerator()
	{
		return numerator;
	}
	
	public int getDenominator()
	{
		return denominator;
	}
	
	public Fraction add(Fraction secondFraction)
	{
		makeCommonDenominators(this, secondFraction);
				
		setNumerator(getNumerator() + secondFraction.getNumerator());
		
		reduce();
		
		return new Fraction(this);
	}
	
	public Fraction subtract(Fraction secondFraction)
	{
		return add(secondFraction.opposite());
	}
	
	public Fraction multiply(Fraction secondFraction)
	{	
		setNumerator(getNumerator() * secondFraction.getNumerator());
		setDenominator(getDenominator() * secondFraction.getDenominator());
		
		reduce();
		
		return new Fraction(this);
	}
	
	public Fraction divide(Fraction secondFraction)
	{
		return multiply(secondFraction.reciprocal());
	}
	
	public String toString()
	{
		return (getNumerator() + "/" + getDenominator());
	}
	
	/// ^^^ Given ^^^ / vvv Other Methods vvv ///
	
	public void setNumerator(int n)
	{
		numerator = n;
	}
	
	public void setDenominator(int d)
	{
		if (d < 0)
		{
			numerator *= -1;
			denominator = -1 * d;
		}
		else
		{
			denominator = d;
		}
	}
	
	private Fraction opposite()
	{
		setNumerator(-1 * getNumerator());
		
		return new Fraction(this);
	}
	
	private Fraction reciprocal()
	{
		int n = getNumerator();
		int d = getDenominator();
		
		return new Fraction(d, n);
	}
	
	private void mutiplyBaseBy(int base)
	{
		setNumerator(getNumerator() * base);
		setDenominator(getDenominator() * base);
	}
	
	private void makeCommonDenominators(Fraction f1, Fraction f2)
	{
		int base1 = f1.getDenominator();
		int base2 = f2.getDenominator();
		
		f1.mutiplyBaseBy(base2);
		f2.mutiplyBaseBy(base1);
	}
	
	public Fraction reduce()
	{	
		final int d = getDenominator();
		
		if (getNumerator() != 0 || d != 0)
		{
			for (int i = d ; i >= 1 ; i--)
			{
				int l_n = getNumerator();
				int l_d = getDenominator();
				
				if (l_n % i == 0 && l_d % i == 0)
				{
					setNumerator(l_n / i);
					setDenominator(l_d / i);
				}
			}
		}
		
		return new Fraction(this);
	}
	
}
