// Lab 2: Nautical Mile
// Justin Varga

import java.util.Scanner;

public class NauticalMile
{
	public static void main(String[] args)
	{
		Scanner reader = new Scanner(System.in);
	
		// Input
		double numberOfKilometers; 
		
		// Output
		double numberOfNauticalMiles;		
		
		// Other Variables
		double kilometersPerNPTE = 10000.0; // NPTE = distance from North Pole to Equator
		double degreesPerNPTE = 90.0;
		double minutesPerDegree = 60.0;
		double nauticalMilesPerMinute = 1.0;
		
		System.out.print("Enter number of kilometers: ");
		numberOfKilometers = reader.nextDouble();
		
		numberOfNauticalMiles = numberOfKilometers / kilometersPerNPTE * degreesPerNPTE * minutesPerDegree * nauticalMilesPerMinute;
		
		System.out.print(numberOfKilometers);
		System.out.print(" km = ");
		System.out.print(numberOfNauticalMiles);
		System.out.println(" nautical mile(s)");
	}
}

