// Lab 2: GUI Window C
// Justin Varga

import javax.swing.*; // For JFrame and JPanel
import java.awt.*; // For Color and Container

public class GUIWindowC
{
	public static void main(String[] args)
	{
		JFrame theGUI = new JFrame();
		theGUI.setTitle("Third GUI Program");
		theGUI.setSize(300, 200);
		theGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Define Panels (NSEW + C)
		JPanel northPanel = new JPanel();
		northPanel.setBackground(Color.red);
		
		JPanel southPanel = new JPanel();
		southPanel.setBackground(Color.blue);
		
		JPanel eastPanel = new JPanel();
		eastPanel.setBackground(Color.black);
		
		JPanel westPanel = new JPanel();
		westPanel.setBackground(Color.yellow);
		
		JPanel centerPanel = new JPanel();
		centerPanel.setBackground(Color.white);
		
		// Add Panels to GUI
		Container pane = theGUI.getContentPane();
		
		pane.add(northPanel, BorderLayout.NORTH);
		pane.add(southPanel, BorderLayout.SOUTH);
		pane.add(eastPanel, BorderLayout.EAST);
		pane.add(westPanel, BorderLayout.WEST);
		pane.add(centerPanel, BorderLayout.CENTER);
		
		theGUI.setVisible(true);
	}
}
