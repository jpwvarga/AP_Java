// Lab 2: Yield
// Justin Varga

public class Yield
{
	public static void main(String[] args)
	{
		String pleaseYield = 	"-----------------\n" + 
							"\\               /\n" + 
							" \\             / \n" +
							"  \\   Yield   /\n" +
							"   \\         /\n" +
							"    \\       /\n" +
							"     \\     /\n" +
							"      \\   /\n" +
							"       \\ /\n" +
							"        |\n" +
							"        |\n" +
							"        |\n" +
							"        |\n" +
							"        |\n" +
							"        |\n" +
							"        |\n" +
							"        |\n" +
							"__w__w______w__w_\n";
		System.out.print(pleaseYield);
	}
}
