// Lab 2: GUI Window Example 1
// Justin Varga

// Example 2.3: an empty frame

import javax.swing.*; // Access JFrame

public class GUIWindowA
{
	public static void main(String[] args)
	{
		JFrame theGUI = new JFrame();
		theGUI.setTitle("First GUI Program");
		theGUI.setSize(300, 200);
		theGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		theGUI.setVisible(true);
	}
}
